#!/system/bin/sh
# PlayIntegrityPro - Runtime Service
MODDIR=${0%/*}

# Wait for boot to finish
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
done

# Wait for GMS
sleep 10

# Clear GMS cache occasionally to force new check (Safe approach)
# pm clear com.google.android.gms # CAUTION: This can be nuclear. 
# Better: Just clear cache.
rm -rf /data/user/0/com.google.android.gms/cache/*

# Late prop sync if needed
# resetprop -n ...
